import { legacy_createStore as createStore } from 'redux'

const initialState = {
  sidebarShow: true,
  theme: 'light',
  rightSidebarShow: true,    
  sidebarUnfoldable: false,
  hoveredDropdownItems: [],
  isLight: "light-theme",
  isAuthenticated: !!localStorage.getItem('token')
  //isDropdownHovered: false,
}




const changeState = (state = initialState, { type, ...rest }) => {
  switch (type) {
    case 'set':
      return { ...state, ...rest }

    case 'setHoveredDropdownItems':
      return { ...state, hoveredDropdownItems: rest.payload }

    case 'clearHoveredDropdownItems':
      return { ...state, hoveredDropdownItems: [] };

      case 'setColorMode':
        return { ...state, isLight: rest.payload };

      case 'login':
        // console.log("from redux", isAuthenticated)
        return { ...state, isAuthenticated: true };
  
      case 'logout':
        return { ...state, isAuthenticated: false };
    
      
    default:
      return state
  }
}

const store = createStore(changeState)
export default store
