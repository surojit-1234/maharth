import { FiLogIn } from "react-icons/fi";
import { FaRegAddressCard } from "react-icons/fa";
import { LuLayoutDashboard } from "react-icons/lu";

const leftMenus = [
  {
    id:1,
    icon: <FiLogIn />,
    name: "Login",
    path: "/login",
    dropdown_items: [
        // {   id: 1,
        //     path: "/forum",
        //     dropdown_icon: <MdOutlineForum />,
        //     dropdown_name: "Forum"
        // } ,
        // {
        //     id: 2,
        //     path: "/assignedProjects",
        //     dropdown_icon: <LuNotebookPen />,
        //     dropdown_name: "Assigned Projects"
        // },
        // {
        //     id: 3,
        //     path: "/guidelines",
        //     dropdown_icon: <SlNotebook />,
        //     dropdown_name: "Guidelines"
        // },
        // {
        //     id: 4,
        //     path: "/attendanceReview",
        //     dropdown_icon: <RiUserStarFill />,
        //     dropdown_name: "Attendence Review"
        // },
        // {
        //     id: 5,
        //     path: "/evaluation",
        //     dropdown_icon: <RiTeamLine />,
        //     dropdown_name: "Evaluation"
        // },
        // {
        //     id: 4,
        //     dropdown_icon: <RiFilePaper2Line />,
        //     path: '/hrPolicy',
        //     dropdown_name: "HR Policy"
        // },
        // {
        //     id: 4,
        //     path: "/folderStructure",
        //     dropdown_icon: <LuFolderTree />,
        //     dropdown_name: "Folder Structure"
        // }
    ]
  },
  {
  id: 2,
  icon: <FaRegAddressCard />,
  name: "Add Lead",
  path: "/add-lead",
  dropdown_items: []
  },
  {
    id: 3,
    icon: <LuLayoutDashboard />,
    name: "Dashboard",
    path: "/dashboard",
    dropdown_items: []
  }
//   {
//     id: 2,
//     icon: <GiDiscussion />,
//     name: "Discussions",
//     path: "",
//     dropdown_items:[
//         // {   id: 1,
//         //     path: "/forum",
//         //     dropdown_icon: <MdOutlineForum />,
//         //     dropdown_name: "Forum"
//         // } ,
//         // {
//         //     id: 2,
//         //     path: "/guidelines",
//         //     dropdown_icon: <SlNotebook />,
//         //     dropdown_name: "Guidelines"
//         // },
//         // {
//         //     id: 3,
//         //     dropdown_icon: <LuNotebookPen />,
//         //     path: "/assignedProjects",
//         //     dropdown_name: "Assigned Projects"
//         // },
//         // {
//         //     id: 4,
//         //     path: "/evaluation",
//         //     dropdown_icon: <RiTeamLine />,
//         //     dropdown_name: "Evaluation"
//         // },
//         // {
//         //     id: 5,
//         //     dropdown_icon: <RiUserStarFill />,
//         //     path: "/attendanceReview",
//         //     dropdown_name: "Attendance Review"
//         // },
//         // {
//         //     id: 4,
//         //     dropdown_icon: <RiFilePaper2Line />,
//         //     path: '/hrPolicy',
//         //     dropdown_name: "HR Policy"
//         // },
//         // {
//         //     id: 4,
//         //     dropdown_icon: <LuFolderTree />,
//         //     path: "/folderStructure",
//         //     dropdown_name: "Folder Structure"
//         // }
//     ]
//   },
//   {
//     id: 3,
//     icon: <MdOutlineNotificationsActive />,
//     name: "Notifications",
//     path: "",
//     dropdown_items:[
//         {   id: 1,
//             path: "/forum",
//             dropdown_icon: <MdOutlineForum />,
//             dropdown_name: "Forum"
//         } ,
//         {
//             id: 2,
//             dropdown_icon: <LuNotebookPen />,
//             path: "/assignedProjects",
//             dropdown_name: "Assigned Projects"
//         },
//         {
//             id: 3,
//             path: "/guidelines",
//             dropdown_icon: <SlNotebook />,
//             dropdown_name: "Guidelines"
//         },
//         {
//             id: 4,
//             dropdown_icon: <RiUserStarFill />,
//             path: "/attendanceReview",
//             dropdown_name: "Attendence Review"
//         },
//         {
//             id: 5,
//             path: "/evaluation",
//             dropdown_icon: <RiTeamLine />,
//             dropdown_name: "Evaluation"
//         },
//         {
//             id: 6,
//             dropdown_icon: <LuFolderTree />,
//             path: "/folderStructure",
//             dropdown_name: "Folder Structure"
//         },
//         {
//             id: 7,
//             dropdown_icon: <RiFilePaper2Line />,
//             path: '/hrPolicy',
//             dropdown_name: "HR POLICY"
//         }
//     ]
//   },
//   {
//     id: 4,
//     icon: <MdOutlineForum />,
//     name: "Forum",
//     path: "",
//     dropdown_items:[
//         {   id: 1,
//             path: "/forum",
//             dropdown_icon: <MdOutlineForum />,
//             dropdown_name: "Forum"
//         } ,
//         {
//             id: 2,
//             dropdown_icon: <LuNotebookPen />,
//             path: "/assignedProjects",
//             dropdown_name: "Assigned Projects"
//         },
//         {
//             id: 3,
//             path: "/guidelines",
//             dropdown_icon: <SlNotebook />,
//             dropdown_name: "Guidelines"
//         },
//         {
//             id: 4,
//             path: "/attendanceReview",
//             dropdown_icon: <RiUserStarFill />,
//             dropdown_name: "Attendence Review"
//         },
//         {
//             id: 5,
//             path: "/evaluation",
//             dropdown_icon: <RiTeamLine />,
//             dropdown_name: "Evaluation"
//         },
//         {
//             id: 6,
//             path: '/hrPolicy',
//             dropdown_icon: <RiFilePaper2Line />,
//             dropdown_name: "HR Policy"
//         }
//     ]
//   },
//   {
//     id: 5,
//     icon: <FaBriefcase />,
//     name: "Portfolio",
//     dropdown_items:[],
//     path: "/portfolio"
//   },
//   {
//     id: 6,
//     icon: <HiOutlinePhoto />,
//     name: "Canvas",
//     dropdown_items:[],
//     path: "/canvas"
//   },
//   {
//     id: 7,
//     icon: <IoAirplaneSharp />,
//     name: "Travel",
//     dropdown_items:[],
//     path: "/travels"
//   },
//   {
//     id: 8,
//     icon: <GrTasks />,
//     name: "Policies",
//     dropdown_items:[],
//     path: '/policies'
//   }

]
 

export default leftMenus