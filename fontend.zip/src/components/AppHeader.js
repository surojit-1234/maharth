import React, { useEffect, useRef, useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { FaBusinessTime } from "react-icons/fa";
import { SlEnvolope } from "react-icons/sl";
import {
  CContainer,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
  CHeader,
  CHeaderNav,
  CHeaderToggler,
  CNavLink,
  CNavItem,
  useColorModes,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';
import {
  cilBell,
  cilContrast,
  cilEnvelopeOpen,
  cilList,
  cilMenu,
  cilMoon,
  cilSun,
} from '@coreui/icons'

import { GoDotFill } from "react-icons/go";
import { MdDoNotDisturbOn } from "react-icons/md";
import { TbLogout2 } from "react-icons/tb";
import { toast } from 'react-toastify';
import { AppHeaderDropdown } from './header/index';
import Logo from "../assets/images/maha-logo.png";  

const AppHeader = () => {
  const navigate = useNavigate();
  const headerRef = useRef();
  const [ colorMode, setColorMode ] = useState('theme');

  useEffect(()=> {
    console.log("Color Mode: ", colorMode);
    dispatch({ type: 'setColorMode', payload: colorMode });
  },[colorMode]);

  const dispatch = useDispatch()
  const sidebarShow = useSelector((state) => state.sidebarShow)

  function handleColorSet(theme) {
    setColorMode(theme);
    localStorage.setItem("theme", theme);
    //console.log("current theme is: ",theme);
  }

  const [selectedItem, setSelectedItem] = useState( <span><GoDotFill style={{ fill: "#1e8e3e" }} /> Active</span> );

  return (
    <CHeader position="sticky" className="mb-4 p-0" ref={headerRef}>
      <CContainer className="px-3 py-2 justify-content-between justify-content-md-start" fluid>
        <CHeaderToggler
          onClick={() =>  {
             dispatch({ type: 'set', sidebarShow: !sidebarShow });
             dispatch({ type: 'setHoveredDropdownItems', payload: [] });
            }
          }
        >
          <CIcon icon={cilMenu} size="xxl" />
        </CHeaderToggler>
        <CHeaderNav className="d-flex mx-md-4"> {/* d-none d-md-flex "Previous it was there"*/}
          <CNavItem>
            <CNavLink to="/dashboard" as={NavLink}>
              <img src={Logo} alt="logo" className="img-fluid" style={{maxWidth: "150px"}}/>
            </CNavLink>
          </CNavItem>
        </CHeaderNav>
 
        <CHeaderNav className="ms-md-auto header-right-side align-items-center">
          {/* <CNavItem>
            <CDropdown>
              <CDropdownToggle href="#" color="secondary" style={{borderRadius: "25px", backgroundColor: "rgba(255, 255, 255, 0.15)"}}>{selectedItem}</CDropdownToggle>
              <CDropdownMenu>
                <CDropdownItem href="#" onClick={()=> setSelectedItem(<span><GoDotFill style={{fill: "#1e8e3e"}}/> Active </span>)}><GoDotFill style={{fill: "#1e8e3e"}}/> Active</CDropdownItem>
                <CDropdownItem href="#" onClick={()=> setSelectedItem(<span><MdDoNotDisturbOn style={{fill: "red"}} /> Do Not Disturb </span>)}><MdDoNotDisturbOn style={{fill: "red"}} /> Do Not Disturb</CDropdownItem>
                <CDropdownItem href="#">Something else here</CDropdownItem>
              </CDropdownMenu>
            </CDropdown>
          </CNavItem>
          <CNavItem>
            <CNavLink href="/"><SlEnvolope className='icon icon-xl'/></CNavLink>
          </CNavItem>
          <CNavItem>
            <CNavLink href="/"><FaBusinessTime className='icon icon-xl' /></CNavLink>
          </CNavItem> */}

          <TbLogout2 
           style={{fontSize:"30px"}} 
           className='logout-icon' 
           onClick={()=> { 
              localStorage.removeItem('token'); 
              setTimeout(()=> {
                navigate("/login");
                toast.success("Logged Out Successfully!");   
              },1000);
            }}
          />
          <CDropdown variant="nav-item" placement="bottom-end">
            <CDropdownToggle caret={false}>
              {colorMode === 'light-theme' ? (
                  <CIcon icon={cilSun} size="lg" />
              ) : (
                <CIcon icon={cilMoon} size="lg" />
              )}
            </CDropdownToggle>
            <CDropdownMenu>
              <CDropdownItem
                active={colorMode === 'light-theme'}
                className="d-flex align-items-center"
                as="button"
                type="button"
                onClick={()=> handleColorSet("light-theme")}
              >
                <CIcon className="me-2" icon={cilSun} size="lg" style={{fontSize:"35px"}} /> Light
              </CDropdownItem>
              <CDropdownItem
                active={colorMode === 'dark-theme'}
                className="d-flex align-items-center"
                as="button"
                type="button"
                onClick={()=> handleColorSet("dark-theme")}
              >
                <CIcon className="me-2" icon={cilMoon} size="lg" style={{fontSize:"35px"}} /> Dark
              </CDropdownItem>
            </CDropdownMenu>
          </CDropdown>
        
          <AppHeaderDropdown />
        </CHeaderNav>
      </CContainer>
      {/* <CContainer className="px-4" fluid>
        <AppBreadcrumb />
      </CContainer> */}
    </CHeader>
  )
}

export default AppHeader
