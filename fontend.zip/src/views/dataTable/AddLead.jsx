import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import './style.css';

const AddLead = () => {
  const [formData, setFormData] = useState({
    fname: '',
    lname: '',
    email: '',
    mobile: '',
    customer_type: '',
    customer_status: '',
    loan_type: '',
    follow_up: '',
    remarks: ''
  });

  const [recordingFile, setRecordingFile] = useState(null);
  const [formErrors, setFormErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === 'customer_status') {
      const statusObj = {
        'Interested': 1,
        'Not Interested': 2,
        'DND': 3
      };
      setFormData((prev) => ({
        ...prev,
        [name]: statusObj[value] || ''
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value
      }));
    }

    setFormErrors((prev) => ({
      ...prev,
      [name]: false
    }));
  };

  const handleFileChange = (e) => {
    console.log(e.target.files[0])
    setRecordingFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const errors = {};
    if (!formData.fname) errors.fname = true;
    if (!formData.lname) errors.lname = true;
    if (!formData.email) errors.email = true;
    if (!formData.mobile) errors.mobile = true;
    if (!formData.customer_type) errors.customer_type = true;
    if (!formData.customer_status) errors.customer_status = true;
    if (!formData.loan_type) errors.loan_type = true;
    if (!formData.follow_up) errors.follow_up= true;
    if (!formData.remarks) errors.remarks = true;

    setFormErrors(errors);

    if (Object.keys(errors).length > 0) {
      toast.error("Please fill all required fields.");
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      toast.error("Token missing. Please log in.");
      return;
    }

    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      data.append(key, value);
    });

    if (recordingFile) {
      data.append('recording_file', recordingFile);
    }

    try {
      const res = await axios.post('http://localhost:8000/maharth/addlead', data, {
        headers: {
          'access-token': token,
          'Content-Type': 'multipart/form-data'
        }
      });

      if (res.data.success) {
        toast.success(res.data.message || "Lead submitted successfully!");
        setFormData({
          fname: '',
          lname: '',
          email: '',
          mobile: '',
          customer_type: '',
          customer_status: '',
          loan_type: '',
          follow_up: '',
          remarks: '',
        });
        setRecordingFile(null);
        setFormErrors({});
      } else {
        toast.error(res.data.message || "Failed to add lead.");
      }
    } catch (err) {
      console.error("Submission error:", err);
      toast.error("Error while submitting the lead.");
    }
  };

  return (
    <div className="container-fluid py-3">
      <div className="row justify-content-center">
        <div className="col-md-12 p-0">
          <div className="card shadow" id="lead-form">
            <div className="card-body py-3">
              <h3 className="mb-4 lead-form-title">Lead Form</h3>
              <form className="row g-3" onSubmit={handleSubmit}>
                <div className="col-md-4">
                  <label htmlFor="inputFn" className="form-label">First Name *</label>
                  <input
                    type="text"
                    className={`form-control ${formErrors.fname ? 'is-invalid' : ''}`}
                    id="inputFn"
                    name="fname"
                    value={formData.fname}
                    onChange={handleChange}
                    placeholder="Your First Name"
                  />
                   <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.fname? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="inputLn" className="form-label">Last Name *</label>
                  <input
                    type="text"
                    className={`form-control ${formErrors.lname ? 'is-invalid' : ''}`}
                    id="inputLn"
                    name="lname"
                    value={formData.lname}
                    onChange={handleChange}
                    placeholder="Your Last Name"
                  />
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.lname? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="inputEmail" className="form-label">Email *</label>
                  <input
                    type="email"
                    className={`form-control ${formErrors.email ? 'is-invalid' : '' }`}
                    id="inputEmail"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Enter Email"
                  />
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.email? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="inputPhone" className="form-label">Phone Number *</label>
                  <input
                    type="text"
                    className={`form-control ${formErrors.mobile ? 'is-invalid' : ''}`}
                    id="inputPhone"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    placeholder="Enter Contact"
                  />
                   <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.mobile? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="inputCustomerType" className="form-label">Customer Type *</label>
                  <select
                    id="inputCustomerType"
                    className={`form-select ${formErrors.customer_type ? 'is-invalid' : ''}`}
                    name="customer_type"
                    value={formData.customer_type}
                    onChange={handleChange}
                  >
                    <option value="">Select</option>
                    <option>Salaried</option>
                    <option>Self Employed</option>
                  </select>
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.customer_type? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="customerStatus" className="form-label">Customer Status *</label>
                  <select
                    id="customerStatus"
                    className={`form-select ${formErrors.customer_status ? 'is-invalid' : ''}`}
                    name="customer_status"
                    onChange={handleChange}
                  >
                    <option value="">Select</option>
                    <option>Interested</option>
                    <option>Not Interested</option>
                    <option>DND</option>
                  </select>
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.customer_status? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="loanType" className="form-label">Loan Type *</label>
                  <select
                    id="loanType"
                    className={`form-select ${formErrors.loan_type ? 'is-invalid' : ''}`}
                    name="loan_type"
                    value={formData.loan_type}
                    onChange={handleChange}
                  >
                    <option value="">Select</option>
                    <option>Business</option>
                    <option>Personal</option>
                    <option>Home</option>
                  </select>
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.loan_type? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-3">
                  <label htmlFor="followUp" className="form-label">Follow Up *</label>
                  <input
                    type="date"
                    className={`form-control ${formErrors.follow_up ? 'is-invalid' : '' }`}
                    id="followUp"
                    name="follow_up"
                    value={formData.follow_up}
                    onChange={handleChange}
                  />
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.follow_up? '*This field is required' : ''}</i>
                </div>
                <div className="col-md-4">
                  <label htmlFor="formFile" className="form-label">Upload File *</label>
                  <input
                    className="form-control"
                    type="file"
                    id="formFile"
                    name="recording_file"
                    onChange={handleFileChange}
                  />
                </div>
                <div className="col-md-12">
                  <label htmlFor="remarks" className="form-label">Remark *</label>
                  <textarea
                    className={`form-control ${formErrors.remarks ? 'is-invalid' : ''}`}
                    id="remarks"
                    name="remarks"
                    rows="4"
                    value={formData.remarks}
                    onChange={handleChange}
                    placeholder="Your Remarks"
                  />
                  <i className='text-danger' style={{fontSize: "13px"}}>{formErrors.remarks? '*This field is required' : ''}</i>
                </div>
                <div className="col-12 mt-4">
                  <button type="submit" className="btn btn-primary w-10" style={{float:"right", backgroundColor:"#009edf"}}>Add Lead</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddLead;
