import React from 'react';
import {
  CTable,
  CTableHead,
  CTableBody,
  CTableRow,
  CTableHeaderCell,
  CTableDataCell,
  CBadge,
} from '@coreui/react';
import './style.css';

const DataTable = () => {
  // const items = [
  //   { id: 1, name: 'John Doe', registered: '2018/01/01', role: 'Member', status: 'Active' },
  //   { id: 2, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Inactive' },
  //   { id: 3, name: 'Subhas Sen', registered: '2018/02/14', role: 'Admin', status: 'Active' },
  //   { id: 4, name: 'Amit Hazra', registered: '2018/02/14', role: 'Admin', status: 'Inactive' },
  //   { id: 5, name: 'Abhishek Sharma', registered: '2018/02/14', role: 'Admin', status: 'Banned' },
  //   { id: 6, name: 'Subhodip Sen', registered: '2018/02/14', role: 'Admin', status: 'Banned' },
  //   { id: 7, name: 'Susmita Sen', registered: '2018/02/14', role: 'Admin', status: 'Active' },
  //   { id: 8, name: 'Anjan Das', registered: '2018/02/14', role: 'Admin', status: 'inactive' },
  //   { id: 9, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Active' },
  //   { id: 10, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Inactive' },
  //   { id: 11, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Inactive' },
  //   { id: 12, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Active' },
  //   { id: 13, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Active' },
  //   { id: 14, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Active' },
  //   { id: 15, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Pending' },
  //   { id: 16, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Inactive' },
  //   { id: 17, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Pending' },
  //   { id: 18, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Pending' },
  //   { id: 19, name: 'Jane Smith', registered: '2018/02/14', role: 'Admin', status: 'Inactive' },
  // ]

  // const columns = [
  //   { key: 'name', label: 'Name', _props: { scope: 'col' } },
  //   { key: 'registered', label: 'Registered', _props: { scope: 'col' } },
  //   { key: 'role', label: 'Role', _props: { scope: 'col' } },
  //   { key: 'status', label: 'Status', _props: { scope: 'col' } },
  // ]

  // const getBadge = (status) => {
  //   return {
  //     Active: 'success',
  //     Inactive: 'secondary',
  //     Pending: 'warning',
  //     Banned: 'danger',
  //   }[status] || 'primary'
  // }

  return (
    <>
{/* <CTable striped hover responsive>
      <CTableHead>
        <CTableRow>
           {columns.map(col => (
             <CTableHeaderCell key={col.key} {...col._props}>{col.label}</CTableHeaderCell>
           ))}
     </CTableRow>
    </CTableHead>
      <CTableBody>
        {items.map(item => (
         <CTableRow key={item.id}>
          <CTableDataCell>{item.name}</CTableDataCell>
           <CTableDataCell>{item.registered}</CTableDataCell>
            <CTableDataCell>{item.role}</CTableDataCell>
          <CTableDataCell>
              <CBadge color={getBadge(item.status)}>{item.status}</CBadge>
           </CTableDataCell>
           </CTableRow>
         ))}
       </CTableBody>
     </CTable> */}
      
  <div className="container py-3">
    <div className="row justify-content-center">
      <div className="col-md-8">
        <div className="card shadow" id="lead-form">
          <div className="card-body">
            <h3 className="mb-4 text-center">Lead Form</h3>
            <form className="row g-3">
              <div className="col-md-6">
                <label htmlFor="inputFn" className="form-label">First Name</label>
                <input type="text" className="form-control" id="inputFn" placeholder='Your First Name' />
              </div>
              <div className="col-md-6">
                <label htmlFor="inputLn" className="form-label">Last Name</label>
                <input type="text" className="form-control" id="inputLn" placeholder='Your Last Name' />
              </div>
              <div className="col-md-6">
                <label htmlFor="inputEmail" className="form-label">Email</label>
                <input type="email" className="form-control" id="inputEmail" placeholder='Enter Email' />
              </div>

              <div className="col-md-6">
                <label htmlFor="inputPhone" className="form-label">Phone</label>
                <input type="tel" className="form-control" id="inputPhone" name="phone" placeholder='Enter Contact' pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" />
              </div>

              <div className="col-md-4">
                <label htmlFor="inputCustomerType" className="form-label">Customer Type</label>
                <select id="inputCustomerType" className="form-select">
                  <option selected>Customer-1</option>
                  <option>Customer-2</option>
                  <option>Customer-3</option>
                </select>
              </div>

              <div className="col-md-4">
                <label htmlFor="customerStatus" className="form-label">Customer Status</label>
                <select id="customerStatus" className="form-select">
                  <option selected>Interested</option>
                  <option>Not Interested</option>
                  <option>DND</option>
                </select>
              </div>

              <div className="col-md-4">
                <label htmlFor="loanType" className="form-label">Loan Type</label>
                <select id="loanType" className="form-select">
                  <option selected>Business Loan</option>
                  <option>Personsal Loan</option>
                  <option>Home Loan</option>
                </select>
              </div>

              <div className="col-md-12">
                <label htmlFor="remarks" className="form-label">Remark</label>
                <textarea className="form-control" id="remark" rows="4" placeholder="Your Remarks"></textarea>
              </div>

              <div className="col-md-6">
                <label htmlFor="followUp" className="form-label">Follow Up</label>
                <input type="date" className="form-control" id="fllowUp" name="followUp" />
              </div>

              <div className="col-md-6">
                <label htmlFor="formFile" className="form-label">Upload File</label>
                <input className="form-control" type="file" id="formFile" />
              </div>

              <div className="col-12">
                <button type="submit" className="btn btn-primary w-100">Submit Now</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

     
    </>
   
    
  )
}

export default DataTable;
