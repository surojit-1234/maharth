import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  CAvatar,
  CBadge,
  CButton,
  CCollapse,
  CSmartTable,
  CCard,
  CCardHeader,
  CCardBody,
} from '@coreui/react-pro';
import './style.css';
import { useNavigate } from 'react-router-dom';
import TruncateText from './TruncateText';
import { FaPlay } from "react-icons/fa";

const getBadge = (status) => {
  switch (status) {
    case 1:
      return 'success'
    case 2:
      return 'secondary'
    case 3:
      return 'danger'
    default:
      return 'primary'
  }
}

const mapStatusText = (status) => {
  switch (status) {
    case 1:
      return 'Interested'
    case 2:
      return 'Not Interested'
    case 3:
      return 'DND'
    default:
      return 'Not Selected'
  }
}

const Dashboard = () => {
  const navigate = useNavigate()
  const [details, setDetails] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const toggleDetails = (id) => {
    setDetails((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    )
  }

  const columns = [
    { key: 'telecaller_name', label: 'Telecaller Name', _style: { width: '400px' } },
    { key: 'fname', label: "Customer's First Name", _style: { width: '300px' } },
    { key: 'lname', label: "Customer's Last Name", _style: { width: '300px' } },
    { key: 'email', label: 'Email Id', _style: { width: '300px' } },
    { key: 'mobile', label: 'Mobile No.', _style: { width: '300px' } },
    { key: 'customer_type', label: 'Customer Type', _style: { width: '350px' } },
    { key: 'customer_status', label: 'Customer Status', _style: { width: '360px' } },
    { key: 'loan_type', label: 'Loan Type', _style: { width: '300px' } },
    { key: 'follow_up', label: 'Follow Up', _style: { width: '300px' } },
    // { key: 'calling_date_time', label: 'Calling Date & time', _style: { width: '350px' } },
    { key: 'remarks', label: 'Remarks', _style: { width: '300px' } },
    {
      key: 'recording_file',
      label: 'Recording',
      _style: { width: '200px' },
      filter: false,
      sorter: false,
    },
    // {
    //   key: 'show_details',
    //   label: 'Action',
    //   filter: false,
    //   sorter: false,
    //   _style: { width: '200px' },
    // },
  ]

  useEffect(() => {
    const fetchLeads = async () => {
      const token = localStorage.getItem('token')
      if (!token) {
        alert('Token not found, please login')
        setLoading(false)
        return
      }

      try {
        const res = await axios.get('http://localhost:8000/maharth/alllead', {
          headers: { 'access-token': token },
        })
        if (res.data.success) {
          setItems(res.data.data)
          console.log("Lead-data", res.data.data)
        } else {
          alert(res.data.msg || 'Failed to fetch leads')
        }
      } catch (error) {
        console.error('Fetch leads error:', error)
        alert('Error fetching leads')
      } finally {
        setLoading(false)
      }
    }
    fetchLeads()
  }, [])

  if (loading) {
    return <div className="container py-3">Loading leads...</div>
  }

  if (items.length === 0) {
    return <div className="container py-3">No leads found.</div>
  }

  return (
    <section className='dashboard-wrap my-3'>
      <CCard>
        <CCardHeader className='d-flex align-items-center justify-content-between'>
          <strong>Dashboard</strong>
          <button className='btn btn-outline-primary' id="lead-button" onClick={() => navigate('/add-lead')}>
            Add New Lead
          </button>
        </CCardHeader>
        <CCardBody>
          <CSmartTable
            className="dataTable-2"
            columns={columns}
            items={items}
            // columnFilter
            columnSorter
            pagination
            itemsPerPageSelect
            itemsPerPage={10}
            cleaner
            clickableRows
            selectable
            scopedColumns={{
              telecaller_name: (item) => (
                <td><TruncateText text={item.telecaller_name} /></td>
              ),
              // fname: (item) => (
              //   <td><TruncateText text={item.fname} /></td>
              // ),
              // lname: (item) => (
              //   <td><TruncateText text={item.lname} /></td>
              // ),
              email: (item) => (
                <td><TruncateText text={item.email} maxLength={6} /></td>
              ),
              mobile: (item) => (
                <td><TruncateText text={item.mobile} maxLength={5} /></td>
              ),
              customer_type: (item) => (
                <td><TruncateText text={item.customer_type} maxLength={6} /></td>
              ),
              remarks: (item) => (
                <td><TruncateText text={item.remarks} maxLength={10} /></td>
              ),
              follow_up: (item) => {
                if (!item.follow_up) return <td></td>
                const date = new Date(item.follow_up)
                return (
                  <td>
                    {date.toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </td>
                )
              },
              // calling_date_time: (item) => {
              //   if (!item.calling_date_time) return <td></td>
              //   const dateTime = new Date(item.calling_date_time)
              //   return (
              //     <td>
              //       {dateTime.toLocaleDateString('en-US', {
              //         year: 'numeric',
              //         month: 'short',
              //         day: 'numeric',
              //       })}
              //     </td>
              //   )
              // },
              customer_status: (item) => (
                <td>
                  <CBadge color={getBadge(item.customer_status)}>
                    {mapStatusText(item.customer_status)}
                  </CBadge>
                </td>
              ),
              recording_file: (item) => (
                <td>
                  {item.recording_file ? (
                    <a
                      href={`http://localhost:8000/uploads/${item.recording_file}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                     <FaPlay />
                    </a>
                  ) : (
                    'No file'
                  )}
                </td>
              ),
              // show_details: (item) => (
              //   <td className="py-2">
              //     <CButton
              //       color="primary"
              //       variant="outline"
              //       shape="square"
              //       size="sm"
              //       onClick={() => toggleDetails(item.id)}
              //     >
              //       {details.includes(item.id) ? 'Hide' : 'Show'}
              //     </CButton>
              //   </td>
              // ),
              // details: (item) =>
              //   details.includes(item.id) && (
              //     <CCollapse visible={true}>
              //       <div className="p-3">
              //         <h4>{item.fname} {item.lname}</h4>
              //         <p className="text-body-secondary">
              //           Email: {item.email} <br />
              //           Mobile: {item.mobile} <br />
              //           Remarks: {item.remarks}
              //         </p>
              //         <CButton size="sm" color="info">
              //           Edit
              //         </CButton>
              //         <CButton size="sm" color="danger" className="ms-1">
              //           Delete
              //         </CButton>
              //       </div>
              //     </CCollapse>
              //   ),
            }}
            tableProps={{ responsive: true, hover: true, striped: true }}
            tableBodyProps={{ className: 'align-middle' }}
          />
        </CCardBody>
      </CCard>
    </section>
  )
}

export default Dashboard;
