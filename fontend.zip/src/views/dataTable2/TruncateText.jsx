// TruncateText.js
import React, { useState } from 'react'

const TruncateText = ({ text, maxLength = 4 }) => {
  const [expanded, setExpanded] = useState(false)

  if (!text) return null

  const toggle = () => setExpanded((prev) => !prev)

  if (text.length <= maxLength) {
    return <span>{text}</span>
  }

  return (
    <span onClick={toggle} style={{ cursor: 'pointer', color: '#0d6efd' }}>
      {expanded ? text : `${text.slice(0, maxLength)}...`}
    </span>
  )
}

export default TruncateText;
